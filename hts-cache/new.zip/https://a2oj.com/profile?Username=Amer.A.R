



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">








<html xmlns="http://www.w3.org/1999/xhtml">
<head>



<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Amer.A.R - A2 Online Judge</title>

<meta name="description" content="A2 Online Judge (or Virtual Online Contests) is an online judge with hundreds of problems and it helps you to create, run and participate in virtual contests using problems from the following online judges: A2 Online Judge, Live Archive, Codeforces, Timus, SPOJ, TJU, SGU, PKU, ZOJ, URI. It also helps you to manage and track your programming comepetions training for you and your friends. It helps for ICPC ACM and IOI training also.">
<meta name="keywords" content="ahmed aly,ahmed aly tools,voc,virtual online contests,programming,c++,java,contest,contests,competition,competitions,programming contest,programming contests,programming compitition,programming compititions,cf,codeforces,live archive,uva,spoj,tju,sgu,pku,timus,zoj,uri,programming tools,a2oj,a2 online judge">
<meta name="author" content="Ahmed Aly">
<link href="default.css" rel="stylesheet" type="text/css" />

		<link rel="stylesheet" href="css/nav.css" />
		<!--[if IE]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

<!-- START TRACKING CODE -->
<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push( [ '_setAccount', 'UA-16947566-3' ]);
	_gaq.push( [ '_trackPageview' ]);

	( function() {
		var ga = document.createElement('script');
		ga.type = 'text/javascript';
		ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl'
				: 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0];
		s.parentNode.insertBefore(ga, s);
	})();
</script>
<!-- END TRACKING CODE -->







</head>
<body class="no-js">
    	<script>
			var el = document.getElementsByTagName("body")[0];
			el.className = "";
		</script>
        <noscript>
        	<!--[if IE]>
            	<link rel="stylesheet" href="css/ie.css">
            <![endif]-->
        </noscript>
        

<center>
<table width="100%">
<tr>
<td>
        


<div id="wrapper"><!-- start header -->

<div id="logo">
<table width="100%">
<tr>
<td style="vertical-align: bottom;"><a href="/"><img src="logo.png"></a></td>
<td>
<h1 style="padding-top: 11px;">A<sup>2</sup> Online Judge</h1>
<h2 class="author">&raquo;&nbsp;&nbsp;&nbsp;&nbsp; by <a href="https://www.facebook.com/ahmed.aly.tc" target="_blank" style="text-decoration: none;">Ahmed Aly</a></h2>
<br/>
<h3>Sponsored by <b><a href="https://www.facebook.com/elcoachacademy/" target="_blank" style="text-decoration: none;">Coach Academy</a></b> & <b><a href="https://www.facebook.com/AfricaArabCPC/" target="_blank" style="text-decoration: none;">ACPC</a></b></h3>
</td>
<td style="text-align: right; padding-top: 27px;">
<iframe src="https://www.facebook.com/plugins/like.php?show_faces=false&href=https://www.facebook.com/A2OnlineJudge"
	scrolling="no" frameborder="0"
	style="border:none; height:45px"></iframe>
</td>
</tr>
</table>
</div>

<div id="header3"><div align="right"><a href="signin?url=%2Fprofile%3FUsername%3DAmer.A.R" style="font-size: 15px;">Sign In</a> - <a href="signup" style="font-size: 15px;">Sign Up</a></div></div>


<div id="header2">
<div id="menu2">

        <nav id="topNav">
          <ul>
<li><a href="/">Contests</a></li><li><a href="ladders"><font color="red">Ladders</font></a></li><li><a href="ps">Problems</a></li><li><a href="status">Status</a></li><li><a href="categories">Categories</a></li><li><a href="groups">Groups</a></li><li><a href="javascript:void();">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;More&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a><ul><li><center><a href="codes">Source Codes</a></center></li><li><center><a href="finder">Problems Finder</a></center></li><li><center><a href="users">Users</a></center></li><li><center><a href="teams">Teams</a></center></li><li><center><a href="cumulative">Cumulative Rank</a></center></li></ul></li><li class="last"><a href="about">About</a></li>
          </ul>
        </nav>
        
        <script src="js/jquery.js"></script>
        <script src="js/modernizr.js"></script>
		<script>
			(function($){
				
				//cache nav
				var nav = $("#topNav");
				
				//add indicator and hovers to submenu parents
				nav.find("li").each(function() {
					if ($(this).find("ul").length > 0) {
						$("<span>").text("^").appendTo($(this).children(":first"));

						//show subnav on hover
						$(this).mouseenter(function() {
							$(this).find("ul").stop(true, true).slideDown();
						});
						
						//hide submenus on exit
						$(this).mouseleave(function() {
							$(this).find("ul").stop(true, true).slideUp();
						});
					}
				});
			})(jQuery);
		</script>


</div>
</div>
<!-- end header --></div>
<!-- start page -->
</td>
</tr>


<tr>

<td style="vertical-align: top;">
<center>
<table>
<tr style="max-height: 0px; padding: 0px;">
<td style="max-height: 0px; padding: 0px; min-width: 165px;"></td>
<td style="max-height: 0px; padding: 0px; min-width: 1060px;"></td>
<td style="max-height: 0px; padding: 0px; min-width: 165px;"></td>
</tr>
<tr>
<td style="padding: 0px; vertical-align: top;">
<div id="leftAd">


</div>
</td>
<td style="padding: 0px; vertical-align: top;">
<div id="page">

<font size="3">
<center>










<b>
<font size=5>
<u>
Amer.A.R's Coder Profile (Jordan)

</u>

</font>
</b>

<br/><br/><b><a href="status?Username=Amer.A.R">Amer.A.R's A2 Online Judge Submissions</a></b>

<br/><br/>
<table border="1" cellpadding="5">

<tr>
<td><b>A2 Online Judge Solved Problems Count</b></td>
<td title="A2 Online Judge Profile"><center>73</center></td>
</tr>


<tr>
<td><b>All Solved Problems Count</b></td>
<td><center>459
</center></td>
</tr>

<tr>
<td><b>UVA Solved Problems Count</b></td>
<td title="UVA Profile"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_authorstats&amp;userid=647571" target="_blank">47</a></center></td>
</tr>
<tr>
<td><b>SPOJ Solved Problems Count</b></td>
<td title="SPOJ Profile"><center><a href="https://www.spoj.com/users/amer_rawashdeh/" target="_blank">19</a>
</center></td>
</tr>
<tr>
<td><b>Live Archive Solved Problems Count</b></td>
<td title="Live Archive Profile"><center><a href="https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&amp;page=show_authorstats&amp;userid=153149" target="_blank">2</a>
</center></td>
</tr>
<tr>
<td><b>Codeforces Solved Problems Count</b></td>
<td title="Codeforces Profile"><center><a href="http://codeforces.com/profile/Amer.A.R" target="_blank">314</a>
</center></td>
</tr>
<tr>
<td><b>SGU Solved Problems Count</b></td>
<td title="SGU Profile"><center><a href="http://acm.sgu.ru/teaminfo.php?id=066825" target="_blank">0</a>
</center></td>
</tr>
<tr>
<td><b>Timus Solved Problems Count</b></td>
<td title="Timus Profile"><center><a href="http://acm.timus.ru/author.aspx?id=195348" target="_blank">0</a>
</center></td>
</tr>
<tr>
<td><b>URI Solved Problems Count</b></td>
<td title="URI Profile"><center><center><a href="https://www.urionlinejudge.com.br/judge/en/profile/36402" target="_blank">4</a>
</center></td>
</tr>


</table>
<br/><br/>
<b style="font: 22px arial, sans-serif;
  color: #5C5C5C;">A2 Online Judge Solved Problems (73 Problems)</b>
<p style="border-bottom: 1px solid #5C5C5C;
  padding-bottom: 6px;
  margin-bottom: 1em;">
</p>

<table border="1" cellpadding="5">
<tr>
<td title="Omar"><center><a href="p?ID=1">1</a></center></td>
<td title="Balloons Colors"><center><a href="p?ID=6">6</a></center></td>
<td title="Kids Love Candies"><center><a href="p?ID=17">17</a></center></td>
<td title="Contest Hall Preparation"><center><a href="p?ID=22">22</a></center></td>
<td title="Arabic and English"><center><a href="p?ID=24">24</a></center></td>
<td title="Between the Mountains"><center><a href="p?ID=25">25</a></center></td>
<td title="Abdelrahman"><center><a href="p?ID=67">67</a></center></td>
<td title="Facebook"><center><a href="p?ID=77">77</a></center></td>
<td title="Mohammed Refaat"><center><a href="p?ID=80">80</a></center></td>
<td title="Teams"><center><a href="p?ID=122">122</a></center></td>
<td title="Subtraction"><center><a href="p?ID=129">129</a></center></td>
<td title="Triangles"><center><a href="p?ID=131">131</a></center></td>
<td title="Anagram String"><center><a href="p?ID=132">132</a></center></td>
<td title="RLE Secret"><center><a href="p?ID=139">139</a></center></td>
<td title="Shuffling"><center><a href="p?ID=144">144</a></center></td>
</tr>
<tr>
<td title="Fibo"><center><a href="p?ID=150">150</a></center></td>
<td title="Ahmad &amp; Sally"><center><a href="p?ID=152">152</a></center></td>
<td title="Easy Sum-2"><center><a href="p?ID=155">155</a></center></td>
<td title="3000 BC"><center><a href="p?ID=158">158</a></center></td>
<td title="Nth Smallest Value"><center><a href="p?ID=159">159</a></center></td>
<td title="The Photographer"><center><a href="p?ID=161">161</a></center></td>
<td title="Circle Of Death"><center><a href="p?ID=164">164</a></center></td>
<td title="Segments"><center><a href="p?ID=166">166</a></center></td>
<td title="Parentheses"><center><a href="p?ID=168">168</a></center></td>
<td title="Dots"><center><a href="p?ID=171">171</a></center></td>
<td title="Rami and Toys"><center><a href="p?ID=178">178</a></center></td>
<td title="Rami and The Number 7"><center><a href="p?ID=179">179</a></center></td>
<td title="Rami The Accountant"><center><a href="p?ID=180">180</a></center></td>
<td title="Rami and Children"><center><a href="p?ID=181">181</a></center></td>
<td title="Rami and Squares"><center><a href="p?ID=182">182</a></center></td>
</tr>
<tr>
<td title="Strings with Same Letters"><center><a href="p?ID=184">184</a></center></td>
<td title="Cryptoquote"><center><a href="p?ID=186">186</a></center></td>
<td title="The Missing Date"><center><a href="p?ID=192">192</a></center></td>
<td title="Omar Loves Candies, Again"><center><a href="p?ID=193">193</a></center></td>
<td title="Connecting Ropes"><center><a href="p?ID=194">194</a></center></td>
<td title="Fair Fegla"><center><a href="p?ID=196">196</a></center></td>
<td title="Flirt With Girls"><center><a href="p?ID=201">201</a></center></td>
<td title="Detective H"><center><a href="p?ID=202">202</a></center></td>
<td title="MCQ Exam"><center><a href="p?ID=203">203</a></center></td>
<td title="Class Statistics"><center><a href="p?ID=213">213</a></center></td>
<td title="String LD"><center><a href="p?ID=233">233</a></center></td>
<td title="Modulo"><center><a href="p?ID=246">246</a></center></td>
<td title="ABC"><center><a href="p?ID=252">252</a></center></td>
<td title="Dwarves"><center><a href="p?ID=255">255</a></center></td>
<td title="R2"><center><a href="p?ID=259">259</a></center></td>
</tr>
<tr>
<td title="EIII Extra"><center><a href="p?ID=275">275</a></center></td>
<td title="Cafeteria"><center><a href="p?ID=277">277</a></center></td>
<td title="iPhone 6!"><center><a href="p?ID=283">283</a></center></td>
<td title="Dice Game"><center><a href="p?ID=298">298</a></center></td>
<td title="Train Passengers"><center><a href="p?ID=306">306</a></center></td>
<td title="Buses To Sharm"><center><a href="p?ID=307">307</a></center></td>
<td title="Enter The Contest"><center><a href="p?ID=308">308</a></center></td>
<td title="Meeting Point"><center><a href="p?ID=315">315</a></center></td>
<td title="Camping"><center><a href="p?ID=317">317</a></center></td>
<td title="The Last Digit"><center><a href="p?ID=322">322</a></center></td>
<td title="Last Fibo"><center><a href="p?ID=323">323</a></center></td>
<td title="Course Scheduling"><center><a href="p?ID=325">325</a></center></td>
<td title="Pizzas"><center><a href="p?ID=326">326</a></center></td>
<td title="Mission"><center><a href="p?ID=327">327</a></center></td>
<td title="Let's Play Tawla"><center><a href="p?ID=329">329</a></center></td>
</tr>
<tr>
<td title="Special Christmas Tree"><center><a href="p?ID=334">334</a></center></td>
<td title="Add them twice"><center><a href="p?ID=346">346</a></center></td>
<td title="Simple Math"><center><a href="p?ID=347">347</a></center></td>
<td title="Magdy"><center><a href="p?ID=350">350</a></center></td>
<td title="Max or Sum?"><center><a href="p?ID=352">352</a></center></td>
<td title="Count to N"><center><a href="p?ID=353">353</a></center></td>
<td title="Supermarket"><center><a href="p?ID=357">357</a></center></td>
<td title="Aki"><center><a href="p?ID=362">362</a></center></td>
<td title="Buying in Bulk"><center><a href="p?ID=381">381</a></center></td>
<td title="The Suffix Game"><center><a href="p?ID=382">382</a></center></td>
<td title="Counting Triangles"><center><a href="p?ID=384">384</a></center></td>
<td title="Are We Stopping Again?"><center><a href="p?ID=387">387</a></center></td>
<td title="Omar 2.0"><center><a href="p?ID=391">391</a></center></td>
<td></td>
<td></td>
</table>


<br/><br/>
<b style="font: 22px arial, sans-serif;
  color: #5C5C5C;">UVA Solved Problems (<a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_authorstats&amp;userid=647571" target="_blank" title="UVA Profile">47 Problems</a>)</b>
<p style="border-bottom: 1px solid #5C5C5C;
  padding-bottom: 6px;
  margin-bottom: 1em;">
</p>

<table border="1" cellpadding="5">
<tr>
<td title="The 3n + 1 problem"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=36" target="_blank">100</a></center></td>
<td title="Greedy Gift Givers"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=55" target="_blank">119</a></center></td>
<td title="TEX Quotes"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=208" target="_blank">272</a></center></td>
<td title="Word Index"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=358" target="_blank">417</a></center></td>
<td title="Knight Moves"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=380" target="_blank">439</a></center></td>
<td title="Graph Connectivity"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=400" target="_blank">459</a></center></td>
<td title="Word Scramble"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=424" target="_blank">483</a></center></td>
<td title="The Department of Redundancy Department"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=425" target="_blank">484</a></center></td>
<td title="Kindergarten Counting Game"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=435" target="_blank">494</a></center></td>
<td title="Oil Deposits"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=513" target="_blank">572</a></center></td>
<td title="Parentheses Balance"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=614" target="_blank">673</a></center></td>
<td title="Network Connections"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=734" target="_blank">793</a></center></td>
<td title="Password Search"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=843" target="_blank">902</a></center></td>
<td title="Number Maze"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=870" target="_blank">929</a></center></td>
<td title="Fibonaccimal Base"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=889" target="_blank">948</a></center></td>
</tr>
<tr>
<td title="The Suspects"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=3638" target="_blank">1197</a></center></td>
<td title="All Roads Lead Where?"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=950" target="_blank">10009</a></center></td>
<td title="Audiophobia"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=989" target="_blank">10048</a></center></td>
<td title="Hashmat the Brave Warrior"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=996" target="_blank">10055</a></center></td>
<td title="Highways"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1088" target="_blank">10147</a></center></td>
<td title="The Hotel with Infinite Rooms"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1111" target="_blank">10170</a></center></td>
<td title="Connect the Campus"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1338" target="_blank">10397</a></center></td>
<td title="Ubiquitous Religions"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1524" target="_blank">10583</a></center></td>
<td title="Friends"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1549" target="_blank">10608</a></center></td>
<td title="Traffic Flow"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1783" target="_blank">10842</a></center></td>
<td title="Find the Telephone"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1862" target="_blank">10921</a></center></td>
<td title="Mother bear"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1886" target="_blank">10945</a></center></td>
<td title="Sending email"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=1927" target="_blank">10986</a></center></td>
<td title="Relational Operator"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2113" target="_blank">11172</a></center></td>
<td title="Three-square"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2317" target="_blank">11342</a></center></td>
</tr>
<tr>
<td title="Shopaholic"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2354" target="_blank">11369</a></center></td>
<td title="Virtual Friends"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2498" target="_blank">11503</a></center></td>
<td title="Automatic Answer"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2542" target="_blank">11547</a></center></td>
<td title="Train Tracks"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2633" target="_blank">11586</a></center></td>
<td title="Image Coding"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2635" target="_blank">11588</a></center></td>
<td title="Burger Time?"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2708" target="_blank">11661</a></center></td>
<td title="Sub-prime"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2726" target="_blank">11679</a></center></td>
<td title="Cost Cutting"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2827" target="_blank">11727</a></center></td>
<td title="Horror Dash"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2899" target="_blank">11799</a></center></td>
<td title="Bafana Bafana"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2905" target="_blank">11805</a></center></td>
<td title="Abnormal 89's"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=2988" target="_blank">11888</a></center></td>
<td title="I Can Guess the Data Structure!"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=3146" target="_blank">11995</a></center></td>
<td title="One-Two-Three"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=3710" target="_blank">12289</a></center></td>
<td title="Save Setu"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=3834" target="_blank">12403</a></center></td>
<td title="Scarecrow"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=3836" target="_blank">12405</a></center></td>
</tr>
<tr>
<td title="Hajj-e-Akbar"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=4022" target="_blank">12577</a></center></td>
<td title="Slogan Learning of Princess"><center><a href="https://uva.onlinejudge.org/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=4270" target="_blank">12592</a></center></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</table>
<br/><br/>
<b style="font: 22px arial, sans-serif;
  color: #5C5C5C;">SPOJ Solved Problems (<a href="https://www.spoj.com/users/amer_rawashdeh/" target="_blank" title="SPOJ Profile">19 Problems</a>)</b>
<p style="border-bottom: 1px solid #5C5C5C;
  padding-bottom: 6px;
  margin-bottom: 1em;">
</p>

<table border="1" cellpadding="5">
<tr>
<td title="Adding Reversed Numbers"><center><a href="http://www.spoj.com/problems/ADDREV/" target="_blank">ADDREV</a></center></td>
<td title="Adding two numbers"><center><a href="http://www.spoj.com/problems/ADUN/" target="_blank">ADUN</a></center></td>
<td title="Seinfeld"><center><a href="http://www.spoj.com/problems/ANARC09A/" target="_blank">ANARC09A</a></center></td>
<td title="Army Strength"><center><a href="http://www.spoj.com/problems/ARMY/" target="_blank">ARMY</a></center></td>
<td title="A Bug&amp;#8217;s Life"><center><a href="http://www.spoj.com/problems/BUGLIFE/" target="_blank">BUGLIFE</a></center></td>
<td title="prayatna PR"><center><a href="http://www.spoj.com/problems/CAM5/" target="_blank">CAM5</a></center></td>
<td title="Can You Make It Empty 2"><center><a href="http://www.spoj.com/problems/EMTY2/" target="_blank">EMTY2</a></center></td>
<td title="Small factorials"><center><a href="http://www.spoj.com/problems/FCTRL2/" target="_blank">FCTRL2</a></center></td>
<td title="Hello Recursion"><center><a href="http://www.spoj.com/problems/HRECURS/" target="_blank">HRECURS</a></center></td>
</tr>
<tr>
<td title="Hard to solve"><center><a href="http://www.spoj.com/problems/HSOLVE/" target="_blank">HSOLVE</a></center></td>
<td title="The last digit"><center><a href="http://www.spoj.com/problems/LASTDIG/" target="_blank">LASTDIG</a></center></td>
<td title="VALIDATE THE MAZE"><center><a href="http://www.spoj.com/problems/MAKEMAZE/" target="_blank">MAKEMAZE</a></center></td>
<td title="Pebble Solver"><center><a href="http://www.spoj.com/problems/PEBBLE/" target="_blank">PEBBLE</a></center></td>
<td title="Is it a tree"><center><a href="http://www.spoj.com/problems/PT07Y/" target="_blank">PT07Y</a></center></td>
<td title="Longest path in a tree"><center><a href="http://www.spoj.com/problems/PT07Z/" target="_blank">PT07Z</a></center></td>
<td title="Running Median"><center><a href="http://www.spoj.com/problems/RMID/" target="_blank">RMID</a></center></td>
<td title="Running Median Again"><center><a href="http://www.spoj.com/problems/RMID2/" target="_blank">RMID2</a></center></td>
<td title="Life, the Universe, and Everything"><center><a href="http://www.spoj.com/problems/TEST/" target="_blank">TEST</a></center></td>
</tr>
<tr>
<td title="Vitaliy and Pie"><center><a href="http://www.spoj.com/problems/VAPI01/" target="_blank">VAPI01</a></center></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</table>
<br/><br/>
<b style="font: 22px arial, sans-serif;
  color: #5C5C5C;">Live Archive Solved Problems (<a href="https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&amp;page=show_authorstats&amp;userid=153149" target="_blank" title="Live Archive Profile">2 Problems</a>)</b>
<p style="border-bottom: 1px solid #5C5C5C;
  padding-bottom: 6px;
  margin-bottom: 1em;">
</p>

<table border="1" cellpadding="5">
<tr>
<td title="What does the fox say?"><center><a href="https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=4592" target="_blank">6581</a></center></td>
<td title="Bus"><center><a href="https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&amp;page=show_problem&amp;problem=4602" target="_blank">6591</a></center></td>
</table>
<br/><br/>
<b style="font: 22px arial, sans-serif;
  color: #5C5C5C;">Codeforces Solved Problems (<a href="http://codeforces.com/profile/Amer.A.R" target="_blank" title="Codeforces Profile">314 Problems</a>)</b>
<p style="border-bottom: 1px solid #5C5C5C;
  padding-bottom: 6px;
  margin-bottom: 1em;">
</p>

<table border="1" cellpadding="5">
<tr>
<td title="Card Game"><center><a href="http://codeforces.com/problemset/problem/106/A" target="_blank">106A</a></center></td>
<td title="Palindromic Times"><center><a href="http://codeforces.com/problemset/problem/108/A" target="_blank">108A</a></center></td>
<td title="Lucky Sum of Digits"><center><a href="http://codeforces.com/problemset/problem/109/A" target="_blank">109A</a></center></td>
<td title="Nearly Lucky Number"><center><a href="http://codeforces.com/problemset/problem/110/A" target="_blank">110A</a></center></td>
<td title="Lucky String"><center><a href="http://codeforces.com/problemset/problem/110/B" target="_blank">110B</a></center></td>
<td title="Petya and Strings"><center><a href="http://codeforces.com/problemset/problem/112/A" target="_blank">112A</a></center></td>
<td title="Cifera"><center><a href="http://codeforces.com/problemset/problem/114/A" target="_blank">114A</a></center></td>
<td title="Party"><center><a href="http://codeforces.com/problemset/problem/115/A" target="_blank">115A</a></center></td>
<td title="Tram"><center><a href="http://codeforces.com/problemset/problem/116/A" target="_blank">116A</a></center></td>
<td title="Little Pigs and Wolves"><center><a href="http://codeforces.com/problemset/problem/116/B" target="_blank">116B</a></center></td>
<td title="String Task"><center><a href="http://codeforces.com/problemset/problem/118/A" target="_blank">118A</a></center></td>
<td title="Present from Lena"><center><a href="http://codeforces.com/problemset/problem/118/B" target="_blank">118B</a></center></td>
<td title="Lucky Division"><center><a href="http://codeforces.com/problemset/problem/122/A" target="_blank">122A</a></center></td>
<td title="Lucky Substring"><center><a href="http://codeforces.com/problemset/problem/122/B" target="_blank">122B</a></center></td>
<td title="The number of positions"><center><a href="http://codeforces.com/problemset/problem/124/A" target="_blank">124A</a></center></td>
</tr>
<tr>
<td title="Canvas Frames"><center><a href="http://codeforces.com/problemset/problem/127/B" target="_blank">127B</a></center></td>
<td title="cAPS lOCK"><center><a href="http://codeforces.com/problemset/problem/131/A" target="_blank">131A</a></center></td>
<td title="HQ9+"><center><a href="http://codeforces.com/problemset/problem/133/A" target="_blank">133A</a></center></td>
<td title="Unary"><center><a href="http://codeforces.com/problemset/problem/133/B" target="_blank">133B</a></center></td>
<td title="Average Numbers"><center><a href="http://codeforces.com/problemset/problem/134/A" target="_blank">134A</a></center></td>
<td title="Presents"><center><a href="http://codeforces.com/problemset/problem/136/A" target="_blank">136A</a></center></td>
<td title="Ternary Logic"><center><a href="http://codeforces.com/problemset/problem/136/B" target="_blank">136B</a></center></td>
<td title="Permutation"><center><a href="http://codeforces.com/problemset/problem/137/B" target="_blank">137B</a></center></td>
<td title="Petr and Book"><center><a href="http://codeforces.com/problemset/problem/139/A" target="_blank">139A</a></center></td>
<td title="New Year Snowmen"><center><a href="http://codeforces.com/problemset/problem/140/C" target="_blank">140C</a></center></td>
<td title="Amusing Joke"><center><a href="http://codeforces.com/problemset/problem/141/A" target="_blank">141A</a></center></td>
<td title="Help Vasilisa the Wise 2"><center><a href="http://codeforces.com/problemset/problem/143/A" target="_blank">143A</a></center></td>
<td title="Arrival of the General"><center><a href="http://codeforces.com/problemset/problem/144/A" target="_blank">144A</a></center></td>
<td title="Lucky Ticket"><center><a href="http://codeforces.com/problemset/problem/146/A" target="_blank">146A</a></center></td>
<td title="Insomnia cure"><center><a href="http://codeforces.com/problemset/problem/148/A" target="_blank">148A</a></center></td>
</tr>
<tr>
<td title="Letter"><center><a href="http://codeforces.com/problemset/problem/14/A" target="_blank">14A</a></center></td>
<td title="Soft Drinking"><center><a href="http://codeforces.com/problemset/problem/151/A" target="_blank">151A</a></center></td>
<td title="Marks"><center><a href="http://codeforces.com/problemset/problem/152/A" target="_blank">152A</a></center></td>
<td title="I_love_\%username\%"><center><a href="http://codeforces.com/problemset/problem/155/A" target="_blank">155A</a></center></td>
<td title="Combination"><center><a href="http://codeforces.com/problemset/problem/155/B" target="_blank">155B</a></center></td>
<td title="Game Outcome"><center><a href="http://codeforces.com/problemset/problem/157/A" target="_blank">157A</a></center></td>
<td title="Trace"><center><a href="http://codeforces.com/problemset/problem/157/B" target="_blank">157B</a></center></td>
<td title="Next Round"><center><a href="http://codeforces.com/problemset/problem/158/A" target="_blank">158A</a></center></td>
<td title="Taxi"><center><a href="http://codeforces.com/problemset/problem/158/B" target="_blank">158B</a></center></td>
<td title="Twins"><center><a href="http://codeforces.com/problemset/problem/160/A" target="_blank">160A</a></center></td>
<td title="Supercentral Point"><center><a href="http://codeforces.com/problemset/problem/165/A" target="_blank">165A</a></center></td>
<td title="Rank List"><center><a href="http://codeforces.com/problemset/problem/166/A" target="_blank">166A</a></center></td>
<td title="Wizards and Demonstration"><center><a href="http://codeforces.com/problemset/problem/168/A" target="_blank">168A</a></center></td>
<td title="Star"><center><a href="http://codeforces.com/problemset/problem/171/B" target="_blank">171B</a></center></td>
<td title="Phone Code"><center><a href="http://codeforces.com/problemset/problem/172/A" target="_blank">172A</a></center></td>
</tr>
<tr>
<td title="Vasya's Calendar"><center><a href="http://codeforces.com/problemset/problem/182/B" target="_blank">182B</a></center></td>
<td title="Comparing Strings"><center><a href="http://codeforces.com/problemset/problem/186/A" target="_blank">186A</a></center></td>
<td title="Cut Ribbon"><center><a href="http://codeforces.com/problemset/problem/189/A" target="_blank">189A</a></center></td>
<td title="Triangle"><center><a href="http://codeforces.com/problemset/problem/18/A" target="_blank">18A</a></center></td>
<td title="Funky Numbers"><center><a href="http://codeforces.com/problemset/problem/192/A" target="_blank">192A</a></center></td>
<td title="Exams"><center><a href="http://codeforces.com/problemset/problem/194/A" target="_blank">194A</a></center></td>
<td title="Plate Game"><center><a href="http://codeforces.com/problemset/problem/197/A" target="_blank">197A</a></center></td>
<td title="Hexadecimal's theorem"><center><a href="http://codeforces.com/problemset/problem/199/A" target="_blank">199A</a></center></td>
<td title="Theatre Square"><center><a href="http://codeforces.com/problemset/problem/1/A" target="_blank">1A</a></center></td>
<td title="Drinks"><center><a href="http://codeforces.com/problemset/problem/200/B" target="_blank">200B</a></center></td>
<td title="Two Problems"><center><a href="http://codeforces.com/problemset/problem/203/A" target="_blank">203A</a></center></td>
<td title="Little Elephant and Rozdil"><center><a href="http://codeforces.com/problemset/problem/205/A" target="_blank">205A</a></center></td>
<td title="Dubstep"><center><a href="http://codeforces.com/problemset/problem/208/A" target="_blank">208A</a></center></td>
<td title="Prizes, Prizes, more Prizes"><center><a href="http://codeforces.com/problemset/problem/208/D" target="_blank">208D</a></center></td>
<td title="BerOS file system"><center><a href="http://codeforces.com/problemset/problem/20/A" target="_blank">20A</a></center></td>
</tr>
<tr>
<td title="Dijkstra?"><center><a href="http://codeforces.com/problemset/problem/20/C" target="_blank">20C</a></center></td>
<td title="System of Equations"><center><a href="http://codeforces.com/problemset/problem/214/A" target="_blank">214A</a></center></td>
<td title="Tiling with Hexagons"><center><a href="http://codeforces.com/problemset/problem/216/A" target="_blank">216A</a></center></td>
<td title="Forming Teams"><center><a href="http://codeforces.com/problemset/problem/216/B" target="_blank">216B</a></center></td>
<td title="Mountain Scenery"><center><a href="http://codeforces.com/problemset/problem/218/A" target="_blank">218A</a></center></td>
<td title="Airport"><center><a href="http://codeforces.com/problemset/problem/218/B" target="_blank">218B</a></center></td>
<td title="k-String"><center><a href="http://codeforces.com/problemset/problem/219/A" target="_blank">219A</a></center></td>
<td title="Little Elephant and Numbers"><center><a href="http://codeforces.com/problemset/problem/221/B" target="_blank">221B</a></center></td>
<td title="Shooshuns and Sequence "><center><a href="http://codeforces.com/problemset/problem/222/A" target="_blank">222A</a></center></td>
<td title="Parallelepiped"><center><a href="http://codeforces.com/problemset/problem/224/A" target="_blank">224A</a></center></td>
<td title="Is your horseshoe on the other hoof?"><center><a href="http://codeforces.com/problemset/problem/228/A" target="_blank">228A</a></center></td>
<td title="Bargaining Table"><center><a href="http://codeforces.com/problemset/problem/22/B" target="_blank">22B</a></center></td>
<td title="Dragons"><center><a href="http://codeforces.com/problemset/problem/230/A" target="_blank">230A</a></center></td>
<td title="T-primes"><center><a href="http://codeforces.com/problemset/problem/230/B" target="_blank">230B</a></center></td>
<td title="Team"><center><a href="http://codeforces.com/problemset/problem/231/A" target="_blank">231A</a></center></td>
</tr>
<tr>
<td title="Perfect Permutation"><center><a href="http://codeforces.com/problemset/problem/233/A" target="_blank">233A</a></center></td>
<td title="Lefthanders and Righthanders "><center><a href="http://codeforces.com/problemset/problem/234/A" target="_blank">234A</a></center></td>
<td title="Boy or Girl"><center><a href="http://codeforces.com/problemset/problem/236/A" target="_blank">236A</a></center></td>
<td title="Free Cash"><center><a href="http://codeforces.com/problemset/problem/237/A" target="_blank">237A</a></center></td>
<td title="Two Bags of Potatoes"><center><a href="http://codeforces.com/problemset/problem/239/A" target="_blank">239A</a></center></td>
<td title="Heads or Tails"><center><a href="http://codeforces.com/problemset/problem/242/A" target="_blank">242A</a></center></td>
<td title="Big Segment"><center><a href="http://codeforces.com/problemset/problem/242/B" target="_blank">242B</a></center></td>
<td title="System Administrator"><center><a href="http://codeforces.com/problemset/problem/245/A" target="_blank">245A</a></center></td>
<td title="Internet Address"><center><a href="http://codeforces.com/problemset/problem/245/B" target="_blank">245B</a></center></td>
<td title="Buggy Sorting"><center><a href="http://codeforces.com/problemset/problem/246/A" target="_blank">246A</a></center></td>
<td title="Increase and Decrease"><center><a href="http://codeforces.com/problemset/problem/246/B" target="_blank">246B</a></center></td>
<td title="Cupboards"><center><a href="http://codeforces.com/problemset/problem/248/A" target="_blank">248A</a></center></td>
<td title="Chilly Willy"><center><a href="http://codeforces.com/problemset/problem/248/B" target="_blank">248B</a></center></td>
<td title="Greg's Workout"><center><a href="http://codeforces.com/problemset/problem/255/A" target="_blank">255A</a></center></td>
<td title="Sockets"><center><a href="http://codeforces.com/problemset/problem/257/A" target="_blank">257A</a></center></td>
</tr>
<tr>
<td title="Little Elephant and Magic Square"><center><a href="http://codeforces.com/problemset/problem/259/B" target="_blank">259B</a></center></td>
<td title="IQ test"><center><a href="http://codeforces.com/problemset/problem/25/A" target="_blank">25A</a></center></td>
<td title="Roma and Lucky Numbers"><center><a href="http://codeforces.com/problemset/problem/262/A" target="_blank">262A</a></center></td>
<td title="Beautiful Matrix"><center><a href="http://codeforces.com/problemset/problem/263/A" target="_blank">263A</a></center></td>
<td title="Colorful Stones (Simplified Edition)"><center><a href="http://codeforces.com/problemset/problem/265/A" target="_blank">265A</a></center></td>
<td title="Roadside Trees (Simplified Edition)"><center><a href="http://codeforces.com/problemset/problem/265/B" target="_blank">265B</a></center></td>
<td title="Stones on the Table"><center><a href="http://codeforces.com/problemset/problem/266/A" target="_blank">266A</a></center></td>
<td title="Queue at the School"><center><a href="http://codeforces.com/problemset/problem/266/B" target="_blank">266B</a></center></td>
<td title="Games"><center><a href="http://codeforces.com/problemset/problem/268/A" target="_blank">268A</a></center></td>
<td title="Regular Bracket Sequence"><center><a href="http://codeforces.com/problemset/problem/26/B" target="_blank">26B</a></center></td>
<td title="Fancy Fence"><center><a href="http://codeforces.com/problemset/problem/270/A" target="_blank">270A</a></center></td>
<td title="Beautiful Year"><center><a href="http://codeforces.com/problemset/problem/271/A" target="_blank">271A</a></center></td>
<td title="Lunch Rush"><center><a href="http://codeforces.com/problemset/problem/276/A" target="_blank">276A</a></center></td>
<td title="Little Girl and Game"><center><a href="http://codeforces.com/problemset/problem/276/B" target="_blank">276B</a></center></td>
<td title="Learning Languages"><center><a href="http://codeforces.com/problemset/problem/277/A" target="_blank">277A</a></center></td>
</tr>
<tr>
<td title="Point on Spiral"><center><a href="http://codeforces.com/problemset/problem/279/A" target="_blank">279A</a></center></td>
<td title="Books"><center><a href="http://codeforces.com/problemset/problem/279/B" target="_blank">279B</a></center></td>
<td title="Next Test"><center><a href="http://codeforces.com/problemset/problem/27/A" target="_blank">27A</a></center></td>
<td title="Word Capitalization"><center><a href="http://codeforces.com/problemset/problem/281/A" target="_blank">281A</a></center></td>
<td title="Bit++"><center><a href="http://codeforces.com/problemset/problem/282/A" target="_blank">282A</a></center></td>
<td title="Painting Eggs"><center><a href="http://codeforces.com/problemset/problem/282/B" target="_blank">282B</a></center></td>
<td title="Cows and Primitive Roots"><center><a href="http://codeforces.com/problemset/problem/284/A" target="_blank">284A</a></center></td>
<td title="Slightly Decreasing Permutations"><center><a href="http://codeforces.com/problemset/problem/285/A" target="_blank">285A</a></center></td>
<td title="Find Marble"><center><a href="http://codeforces.com/problemset/problem/285/B" target="_blank">285B</a></center></td>
<td title="Building Permutation"><center><a href="http://codeforces.com/problemset/problem/285/C" target="_blank">285C</a></center></td>
<td title="Polo the Penguin and Matrix"><center><a href="http://codeforces.com/problemset/problem/289/B" target="_blank">289B</a></center></td>
<td title="Yaroslav and Permutations"><center><a href="http://codeforces.com/problemset/problem/296/A" target="_blank">296A</a></center></td>
<td title="Snow Footprints"><center><a href="http://codeforces.com/problemset/problem/298/A" target="_blank">298A</a></center></td>
<td title="Mail Stamps"><center><a href="http://codeforces.com/problemset/problem/29/C" target="_blank">29C</a></center></td>
<td title="Array"><center><a href="http://codeforces.com/problemset/problem/300/A" target="_blank">300A</a></center></td>
</tr>
<tr>
<td title="Eugeny and Array"><center><a href="http://codeforces.com/problemset/problem/302/A" target="_blank">302A</a></center></td>
<td title="Strange Addition"><center><a href="http://codeforces.com/problemset/problem/305/A" target="_blank">305A</a></center></td>
<td title="Archer"><center><a href="http://codeforces.com/problemset/problem/312/B" target="_blank">312B</a></center></td>
<td title="Ilya and Bank Account"><center><a href="http://codeforces.com/problemset/problem/313/A" target="_blank">313A</a></center></td>
<td title="Ilya and Queries"><center><a href="http://codeforces.com/problemset/problem/313/B" target="_blank">313B</a></center></td>
<td title="Even Odds"><center><a href="http://codeforces.com/problemset/problem/318/A" target="_blank">318A</a></center></td>
<td title="Strings of Power"><center><a href="http://codeforces.com/problemset/problem/318/B" target="_blank">318B</a></center></td>
<td title="Worms Evolution"><center><a href="http://codeforces.com/problemset/problem/31/A" target="_blank">31A</a></center></td>
<td title="Ciel and Dancing"><center><a href="http://codeforces.com/problemset/problem/322/A" target="_blank">322A</a></center></td>
<td title="Ciel and Flowers"><center><a href="http://codeforces.com/problemset/problem/322/B" target="_blank">322B</a></center></td>
<td title="Borze"><center><a href="http://codeforces.com/problemset/problem/32/B" target="_blank">32B</a></center></td>
<td title="Cakeminator"><center><a href="http://codeforces.com/problemset/problem/330/A" target="_blank">330A</a></center></td>
<td title="Road Construction"><center><a href="http://codeforces.com/problemset/problem/330/B" target="_blank">330B</a></center></td>
<td title="Puzzles"><center><a href="http://codeforces.com/problemset/problem/337/A" target="_blank">337A</a></center></td>
<td title="Routine Problem"><center><a href="http://codeforces.com/problemset/problem/337/B" target="_blank">337B</a></center></td>
</tr>
<tr>
<td title="Helpful Maths"><center><a href="http://codeforces.com/problemset/problem/339/A" target="_blank">339A</a></center></td>
<td title="Xenia and Ringroad"><center><a href="http://codeforces.com/problemset/problem/339/B" target="_blank">339B</a></center></td>
<td title="Reconnaissance 2"><center><a href="http://codeforces.com/problemset/problem/34/A" target="_blank">34A</a></center></td>
<td title="Sale"><center><a href="http://codeforces.com/problemset/problem/34/B" target="_blank">34B</a></center></td>
<td title="TL"><center><a href="http://codeforces.com/problemset/problem/350/A" target="_blank">350A</a></center></td>
<td title="Jeff and Periods"><center><a href="http://codeforces.com/problemset/problem/352/B" target="_blank">352B</a></center></td>
<td title="Domino"><center><a href="http://codeforces.com/problemset/problem/353/A" target="_blank">353A</a></center></td>
<td title="Vasya and Digital Root"><center><a href="http://codeforces.com/problemset/problem/355/A" target="_blank">355A</a></center></td>
<td title="Flag Day"><center><a href="http://codeforces.com/problemset/problem/357/B" target="_blank">357B</a></center></td>
<td title="Dima and Continuous Line"><center><a href="http://codeforces.com/problemset/problem/358/A" target="_blank">358A</a></center></td>
<td title="Table"><center><a href="http://codeforces.com/problemset/problem/359/A" target="_blank">359A</a></center></td>
<td title="Shell Game"><center><a href="http://codeforces.com/problemset/problem/35/A" target="_blank">35A</a></center></td>
<td title="Levko and Table"><center><a href="http://codeforces.com/problemset/problem/361/A" target="_blank">361A</a></center></td>
<td title="Petya and Staircases"><center><a href="http://codeforces.com/problemset/problem/362/B" target="_blank">362B</a></center></td>
<td title="Soroban"><center><a href="http://codeforces.com/problemset/problem/363/A" target="_blank">363A</a></center></td>
</tr>
<tr>
<td title="The Fibonacci Segment"><center><a href="http://codeforces.com/problemset/problem/365/B" target="_blank">365B</a></center></td>
<td title="Dima and To-do List"><center><a href="http://codeforces.com/problemset/problem/366/B" target="_blank">366B</a></center></td>
<td title="Rook, Bishop and King"><center><a href="http://codeforces.com/problemset/problem/370/A" target="_blank">370A</a></center></td>
<td title="Collecting Beats is Fun"><center><a href="http://codeforces.com/problemset/problem/373/A" target="_blank">373A</a></center></td>
<td title="Inna and Pink Pony"><center><a href="http://codeforces.com/problemset/problem/374/A" target="_blank">374A</a></center></td>
<td title="Lever"><center><a href="http://codeforces.com/problemset/problem/376/A" target="_blank">376A</a></center></td>
<td title="Maze"><center><a href="http://codeforces.com/problemset/problem/377/A" target="_blank">377A</a></center></td>
<td title="Playing with Dice"><center><a href="http://codeforces.com/problemset/problem/378/A" target="_blank">378A</a></center></td>
<td title="New Year Candles"><center><a href="http://codeforces.com/problemset/problem/379/A" target="_blank">379A</a></center></td>
<td title="Towers"><center><a href="http://codeforces.com/problemset/problem/37/A" target="_blank">37A</a></center></td>
<td title="Bear and Raspberry"><center><a href="http://codeforces.com/problemset/problem/385/A" target="_blank">385A</a></center></td>
<td title="George and Round"><center><a href="http://codeforces.com/problemset/problem/387/B" target="_blank">387B</a></center></td>
<td title="Fox and Number Game"><center><a href="http://codeforces.com/problemset/problem/389/A" target="_blank">389A</a></center></td>
<td title="Army"><center><a href="http://codeforces.com/problemset/problem/38/A" target="_blank">38A</a></center></td>
<td title="Inna and Alarm Clock"><center><a href="http://codeforces.com/problemset/problem/390/A" target="_blank">390A</a></center></td>
</tr>
<tr>
<td title="Nineteen"><center><a href="http://codeforces.com/problemset/problem/393/A" target="_blank">393A</a></center></td>
<td title="On Segment's Own Points"><center><a href="http://codeforces.com/problemset/problem/397/A" target="_blank">397A</a></center></td>
<td title="Shortest path of the king"><center><a href="http://codeforces.com/problemset/problem/3/A" target="_blank">3A</a></center></td>
<td title="Vanya and Cards"><center><a href="http://codeforces.com/problemset/problem/401/A" target="_blank">401A</a></center></td>
<td title="Valera and X"><center><a href="http://codeforces.com/problemset/problem/404/A" target="_blank">404A</a></center></td>
<td title="Line to Cashier"><center><a href="http://codeforces.com/problemset/problem/408/A" target="_blank">408A</a></center></td>
<td title="Garland"><center><a href="http://codeforces.com/problemset/problem/408/B" target="_blank">408B</a></center></td>
<td title="Guess a number!"><center><a href="http://codeforces.com/problemset/problem/416/A" target="_blank">416A</a></center></td>
<td title="Art Union"><center><a href="http://codeforces.com/problemset/problem/416/B" target="_blank">416B</a></center></td>
<td title="Translation"><center><a href="http://codeforces.com/problemset/problem/41/A" target="_blank">41A</a></center></td>
<td title="Choosing Teams"><center><a href="http://codeforces.com/problemset/problem/432/A" target="_blank">432A</a></center></td>
<td title="Football Kit"><center><a href="http://codeforces.com/problemset/problem/432/B" target="_blank">432B</a></center></td>
<td title="The Child and Homework"><center><a href="http://codeforces.com/problemset/problem/437/A" target="_blank">437A</a></center></td>
<td title="The Child and Set"><center><a href="http://codeforces.com/problemset/problem/437/B" target="_blank">437B</a></center></td>
<td title="Devu, the Singer and Churu, the Joker"><center><a href="http://codeforces.com/problemset/problem/439/A" target="_blank">439A</a></center></td>
</tr>
<tr>
<td title="Devu, the Dumb Guy"><center><a href="http://codeforces.com/problemset/problem/439/B" target="_blank">439B</a></center></td>
<td title="Football"><center><a href="http://codeforces.com/problemset/problem/43/A" target="_blank">43A</a></center></td>
<td title="Valera and Antique Items"><center><a href="http://codeforces.com/problemset/problem/441/A" target="_blank">441A</a></center></td>
<td title="Anton and Letters"><center><a href="http://codeforces.com/problemset/problem/443/A" target="_blank">443A</a></center></td>
<td title="DZY Loves Chessboard"><center><a href="http://codeforces.com/problemset/problem/445/A" target="_blank">445A</a></center></td>
<td title="DZY Loves Strings"><center><a href="http://codeforces.com/problemset/problem/447/B" target="_blank">447B</a></center></td>
<td title="Suffix Structures"><center><a href="http://codeforces.com/problemset/problem/448/B" target="_blank">448B</a></center></td>
<td title="Jzzhu and Sequences"><center><a href="http://codeforces.com/problemset/problem/450/B" target="_blank">450B</a></center></td>
<td title="Game With Sticks"><center><a href="http://codeforces.com/problemset/problem/451/A" target="_blank">451A</a></center></td>
<td title="Sort the Array"><center><a href="http://codeforces.com/problemset/problem/451/B" target="_blank">451B</a></center></td>
<td title="Little Pony and Crystal Mine"><center><a href="http://codeforces.com/problemset/problem/454/A" target="_blank">454A</a></center></td>
<td title="Little Pony and Sort by Shift"><center><a href="http://codeforces.com/problemset/problem/454/B" target="_blank">454B</a></center></td>
<td title="Laptops"><center><a href="http://codeforces.com/problemset/problem/456/A" target="_blank">456A</a></center></td>
<td title="Pashmak and Garden"><center><a href="http://codeforces.com/problemset/problem/459/A" target="_blank">459A</a></center></td>
<td title="Appleman and Easy Task"><center><a href="http://codeforces.com/problemset/problem/462/A" target="_blank">462A</a></center></td>
</tr>
<tr>
<td title="Cheap Travel"><center><a href="http://codeforces.com/problemset/problem/466/A" target="_blank">466A</a></center></td>
<td title="George and Accommodation"><center><a href="http://codeforces.com/problemset/problem/467/A" target="_blank">467A</a></center></td>
<td title="Fedor and New Game"><center><a href="http://codeforces.com/problemset/problem/467/B" target="_blank">467B</a></center></td>
<td title="I Wanna Be the Guy"><center><a href="http://codeforces.com/problemset/problem/469/A" target="_blank">469A</a></center></td>
<td title="Chat Online"><center><a href="http://codeforces.com/problemset/problem/469/B" target="_blank">469B</a></center></td>
<td title="MUH and Sticks"><center><a href="http://codeforces.com/problemset/problem/471/A" target="_blank">471A</a></center></td>
<td title="Design Tutorial: Learn from Math"><center><a href="http://codeforces.com/problemset/problem/472/A" target="_blank">472A</a></center></td>
<td title="Keyboard"><center><a href="http://codeforces.com/problemset/problem/474/A" target="_blank">474A</a></center></td>
<td title="Dreamoon and Stairs"><center><a href="http://codeforces.com/problemset/problem/476/A" target="_blank">476A</a></center></td>
<td title="Initial Bet"><center><a href="http://codeforces.com/problemset/problem/478/A" target="_blank">478A</a></center></td>
<td title="Random Teams"><center><a href="http://codeforces.com/problemset/problem/478/B" target="_blank">478B</a></center></td>
<td title="Expression"><center><a href="http://codeforces.com/problemset/problem/479/A" target="_blank">479A</a></center></td>
<td title="Counterexample "><center><a href="http://codeforces.com/problemset/problem/483/A" target="_blank">483A</a></center></td>
<td title="Bits"><center><a href="http://codeforces.com/problemset/problem/484/A" target="_blank">484A</a></center></td>
<td title="Calculating Function"><center><a href="http://codeforces.com/problemset/problem/486/A" target="_blank">486A</a></center></td>
</tr>
<tr>
<td title="OR in Matrix"><center><a href="http://codeforces.com/problemset/problem/486/B" target="_blank">486B</a></center></td>
<td title="Palindrome Transformation"><center><a href="http://codeforces.com/problemset/problem/486/C" target="_blank">486C</a></center></td>
<td title="Giga Tower"><center><a href="http://codeforces.com/problemset/problem/488/A" target="_blank">488A</a></center></td>
<td title="SwapSort"><center><a href="http://codeforces.com/problemset/problem/489/A" target="_blank">489A</a></center></td>
<td title="Rock-paper-scissors"><center><a href="http://codeforces.com/problemset/problem/48/A" target="_blank">48A</a></center></td>
<td title="Team Olympiad"><center><a href="http://codeforces.com/problemset/problem/490/A" target="_blank">490A</a></center></td>
<td title="Vanya and Cubes"><center><a href="http://codeforces.com/problemset/problem/492/A" target="_blank">492A</a></center></td>
<td title="Vanya and Lanterns"><center><a href="http://codeforces.com/problemset/problem/492/B" target="_blank">492B</a></center></td>
<td title="Vasya and Wrestling"><center><a href="http://codeforces.com/problemset/problem/493/B" target="_blank">493B</a></center></td>
<td title="Minimum Difficulty"><center><a href="http://codeforces.com/problemset/problem/496/A" target="_blank">496A</a></center></td>
<td title="Watching a movie"><center><a href="http://codeforces.com/problemset/problem/499/A" target="_blank">499A</a></center></td>
<td title="Lecture"><center><a href="http://codeforces.com/problemset/problem/499/B" target="_blank">499B</a></center></td>
<td title="Sleuth"><center><a href="http://codeforces.com/problemset/problem/49/A" target="_blank">49A</a></center></td>
<td title="Watermelon"><center><a href="http://codeforces.com/problemset/problem/4/A" target="_blank">4A</a></center></td>
<td title="Before an Exam"><center><a href="http://codeforces.com/problemset/problem/4/B" target="_blank">4B</a></center></td>
</tr>
<tr>
<td title="Registration System"><center><a href="http://codeforces.com/problemset/problem/4/C" target="_blank">4C</a></center></td>
<td title="New Year Transportation"><center><a href="http://codeforces.com/problemset/problem/500/A" target="_blank">500A</a></center></td>
<td title="Contest"><center><a href="http://codeforces.com/problemset/problem/501/A" target="_blank">501A</a></center></td>
<td title="Misha and Changing Handles"><center><a href="http://codeforces.com/problemset/problem/501/B" target="_blank">501B</a></center></td>
<td title="Amr and Music"><center><a href="http://codeforces.com/problemset/problem/507/A" target="_blank">507A</a></center></td>
<td title="Amr and Pins"><center><a href="http://codeforces.com/problemset/problem/507/B" target="_blank">507B</a></center></td>
<td title="Anton and currency you all know"><center><a href="http://codeforces.com/problemset/problem/508/B" target="_blank">508B</a></center></td>
<td title="Painting Pebbles"><center><a href="http://codeforces.com/problemset/problem/509/B" target="_blank">509B</a></center></td>
<td title="Domino piling"><center><a href="http://codeforces.com/problemset/problem/50/A" target="_blank">50A</a></center></td>
<td title="Fox And Snake"><center><a href="http://codeforces.com/problemset/problem/510/A" target="_blank">510A</a></center></td>
<td title="Fox And Two Dots"><center><a href="http://codeforces.com/problemset/problem/510/B" target="_blank">510B</a></center></td>
<td title="Game"><center><a href="http://codeforces.com/problemset/problem/513/A" target="_blank">513A</a></center></td>
<td title="Chewba?ca and Number"><center><a href="http://codeforces.com/problemset/problem/514/A" target="_blank">514A</a></center></td>
<td title="Han Solo and Lazer Gun"><center><a href="http://codeforces.com/problemset/problem/514/B" target="_blank">514B</a></center></td>
<td title="Drazil and Date"><center><a href="http://codeforces.com/problemset/problem/515/A" target="_blank">515A</a></center></td>
</tr>
<tr>
<td title="Tanya and Postcard"><center><a href="http://codeforces.com/problemset/problem/518/B" target="_blank">518B</a></center></td>
<td title="A and B and Chess"><center><a href="http://codeforces.com/problemset/problem/519/A" target="_blank">519A</a></center></td>
<td title="A and B and Compilation Errors"><center><a href="http://codeforces.com/problemset/problem/519/B" target="_blank">519B</a></center></td>
<td title="A and B and Team Training"><center><a href="http://codeforces.com/problemset/problem/519/C" target="_blank">519C</a></center></td>
<td title="Pangram"><center><a href="http://codeforces.com/problemset/problem/520/A" target="_blank">520A</a></center></td>
<td title="Two Buttons"><center><a href="http://codeforces.com/problemset/problem/520/B" target="_blank">520B</a></center></td>
<td title="Vitaliy and Pie"><center><a href="http://codeforces.com/problemset/problem/525/A" target="_blank">525A</a></center></td>
<td title="Pasha and String"><center><a href="http://codeforces.com/problemset/problem/525/B" target="_blank">525B</a></center></td>
<td title="Ilya and Sticks"><center><a href="http://codeforces.com/problemset/problem/525/C" target="_blank">525C</a></center></td>
<td title="King of Thieves"><center><a href="http://codeforces.com/problemset/problem/526/A" target="_blank">526A</a></center></td>
<td title="Exam"><center><a href="http://codeforces.com/problemset/problem/534/A" target="_blank">534A</a></center></td>
<td title="Tavas and Nafas"><center><a href="http://codeforces.com/problemset/problem/535/A" target="_blank">535A</a></center></td>
<td title="Tavas and SaDDas"><center><a href="http://codeforces.com/problemset/problem/535/B" target="_blank">535B</a></center></td>
<td title="Combination Lock"><center><a href="http://codeforces.com/problemset/problem/540/A" target="_blank">540A</a></center></td>
<td title="Ice Cave"><center><a href="http://codeforces.com/problemset/problem/540/C" target="_blank">540C</a></center></td>
</tr>
<tr>
<td title="Set of Strings"><center><a href="http://codeforces.com/problemset/problem/544/A" target="_blank">544A</a></center></td>
<td title="Toy Cars"><center><a href="http://codeforces.com/problemset/problem/545/A" target="_blank">545A</a></center></td>
<td title="Mike and Fax"><center><a href="http://codeforces.com/problemset/problem/548/A" target="_blank">548A</a></center></td>
<td title="Mike and Fun"><center><a href="http://codeforces.com/problemset/problem/548/B" target="_blank">548B</a></center></td>
<td title="Ohana Cleans Up"><center><a href="http://codeforces.com/problemset/problem/554/B" target="_blank">554B</a></center></td>
<td title="Case of the Zeros and Ones"><center><a href="http://codeforces.com/problemset/problem/556/A" target="_blank">556A</a></center></td>
<td title="Case of Fake Numbers"><center><a href="http://codeforces.com/problemset/problem/556/B" target="_blank">556B</a></center></td>
<td title="Ilya and Diplomas"><center><a href="http://codeforces.com/problemset/problem/557/A" target="_blank">557A</a></center></td>
<td title="Amr and The Large Array"><center><a href="http://codeforces.com/problemset/problem/558/B" target="_blank">558B</a></center></td>
<td title="Currency System in Geraldion"><center><a href="http://codeforces.com/problemset/problem/560/A" target="_blank">560A</a></center></td>
<td title="Gerald is into Art"><center><a href="http://codeforces.com/problemset/problem/560/B" target="_blank">560B</a></center></td>
<td title="One-Dimensional Battle Ships"><center><a href="http://codeforces.com/problemset/problem/567/D" target="_blank">567D</a></center></td>
<td title="Music"><center><a href="http://codeforces.com/problemset/problem/569/A" target="_blank">569A</a></center></td>
<td title="Inventory"><center><a href="http://codeforces.com/problemset/problem/569/B" target="_blank">569B</a></center></td>
<td title="Bar"><center><a href="http://codeforces.com/problemset/problem/56/A" target="_blank">56A</a></center></td>
</tr>
<tr>
<td title="Arrays"><center><a href="http://codeforces.com/problemset/problem/572/A" target="_blank">572A</a></center></td>
<td title="Order Book"><center><a href="http://codeforces.com/problemset/problem/572/B" target="_blank">572B</a></center></td>
<td title="Multiplication Table"><center><a href="http://codeforces.com/problemset/problem/577/A" target="_blank">577A</a></center></td>
<td title="Asphalting Roads"><center><a href="http://codeforces.com/problemset/problem/583/A" target="_blank">583A</a></center></td>
<td title="Olesya and Rodion"><center><a href="http://codeforces.com/problemset/problem/584/A" target="_blank">584A</a></center></td>
<td title="Duff and Meat"><center><a href="http://codeforces.com/problemset/problem/588/A" target="_blank">588A</a></center></td>
<td title="Duff in Love"><center><a href="http://codeforces.com/problemset/problem/588/B" target="_blank">588B</a></center></td>
<td title="Lottery"><center><a href="http://codeforces.com/problemset/problem/589/I" target="_blank">589I</a></center></td>
<td title="Chat room"><center><a href="http://codeforces.com/problemset/problem/58/A" target="_blank">58A</a></center></td>
<td title="Coins"><center><a href="http://codeforces.com/problemset/problem/58/B" target="_blank">58B</a></center></td>
<td title="Word"><center><a href="http://codeforces.com/problemset/problem/59/A" target="_blank">59A</a></center></td>
<td title="New Year and Days"><center><a href="http://codeforces.com/problemset/problem/611/A" target="_blank">611A</a></center></td>
<td title="New Year and Old Property"><center><a href="http://codeforces.com/problemset/problem/611/B" target="_blank">611B</a></center></td>
<td title="Link/Cut Tree"><center><a href="http://codeforces.com/problemset/problem/614/A" target="_blank">614A</a></center></td>
<td title="Elephant"><center><a href="http://codeforces.com/problemset/problem/617/A" target="_blank">617A</a></center></td>
</tr>
<tr>
<td title="Chocolate"><center><a href="http://codeforces.com/problemset/problem/617/B" target="_blank">617B</a></center></td>
<td title="Ultra-Fast Mathematician"><center><a href="http://codeforces.com/problemset/problem/61/A" target="_blank">61A</a></center></td>
<td title="Save Luke"><center><a href="http://codeforces.com/problemset/problem/624/A" target="_blank">624A</a></center></td>
<td title="Making a String"><center><a href="http://codeforces.com/problemset/problem/624/B" target="_blank">624B</a></center></td>
<td title="Again Twenty Five!"><center><a href="http://codeforces.com/problemset/problem/630/A" target="_blank">630A</a></center></td>
<td title="Ebony and Ivory"><center><a href="http://codeforces.com/problemset/problem/633/A" target="_blank">633A</a></center></td>
<td title="Sinking Ship"><center><a href="http://codeforces.com/problemset/problem/63/A" target="_blank">63A</a></center></td>
<td title="Petya and Countryside"><center><a href="http://codeforces.com/problemset/problem/66/B" target="_blank">66B</a></center></td>
<td title="Summer Camp"><center><a href="http://codeforces.com/problemset/problem/672/A" target="_blank">672A</a></center></td>
<td title="Different is Good"><center><a href="http://codeforces.com/problemset/problem/672/B" target="_blank">672B</a></center></td>
<td title="Infinite Sequence"><center><a href="http://codeforces.com/problemset/problem/675/A" target="_blank">675A</a></center></td>
<td title="Restoring Painting"><center><a href="http://codeforces.com/problemset/problem/675/B" target="_blank">675B</a></center></td>
<td title="Vanya and Fence"><center><a href="http://codeforces.com/problemset/problem/677/A" target="_blank">677A</a></center></td>
<td title="Pineapple Incident"><center><a href="http://codeforces.com/problemset/problem/697/A" target="_blank">697A</a></center></td>
<td title="Barnicle"><center><a href="http://codeforces.com/problemset/problem/697/B" target="_blank">697B</a></center></td>
</tr>
<tr>
<td title="Young Physicist"><center><a href="http://codeforces.com/problemset/problem/69/A" target="_blank">69A</a></center></td>
<td title="Subsegments"><center><a href="http://codeforces.com/problemset/problem/69/E" target="_blank">69E</a></center></td>
<td title="Way Too Long Words"><center><a href="http://codeforces.com/problemset/problem/71/A" target="_blank">71A</a></center></td>
<td title="Life Without Zeros"><center><a href="http://codeforces.com/problemset/problem/75/A" target="_blank">75A</a></center></td>
<td title="Haiku"><center><a href="http://codeforces.com/problemset/problem/78/A" target="_blank">78A</a></center></td>
<td title="Panoramix's Prediction"><center><a href="http://codeforces.com/problemset/problem/80/A" target="_blank">80A</a></center></td>
<td title="Plug-in"><center><a href="http://codeforces.com/problemset/problem/81/A" target="_blank">81A</a></center></td>
<td title="Toy Army"><center><a href="http://codeforces.com/problemset/problem/84/A" target="_blank">84A</a></center></td>
<td title="Chord"><center><a href="http://codeforces.com/problemset/problem/88/A" target="_blank">88A</a></center></td>
<td title="Chips"><center><a href="http://codeforces.com/problemset/problem/92/A" target="_blank">92A</a></center></td>
<td title="Restoring Password"><center><a href="http://codeforces.com/problemset/problem/94/A" target="_blank">94A</a></center></td>
<td title="Football"><center><a href="http://codeforces.com/problemset/problem/96/A" target="_blank">96A</a></center></td>
<td title="Lucky Numbers (easy)"><center><a href="http://codeforces.com/problemset/problem/96/B" target="_blank">96B</a></center></td>
<td title="Die Roll"><center><a href="http://codeforces.com/problemset/problem/9/A" target="_blank">9A</a></center></td>
<td></td>
</table>
<br/><br/>
<b style="font: 22px arial, sans-serif;
  color: #5C5C5C;">URI Solved Problems (<a href="https://www.urionlinejudge.com.br/judge/en/profile/36402" target="_blank" title="URI Profile">4 Problems</a>)</b>
<p style="border-bottom: 1px solid #5C5C5C;
  padding-bottom: 6px;
  margin-bottom: 1em;">
</p>

<table border="1" cellpadding="5">
<tr>
<td title="Extremely Basic"><center><a href="https://www.urionlinejudge.com.br/judge/en/problems/view/1001" target="_blank">1001</a></center></td>
<td title="Difference"><center><a href="https://www.urionlinejudge.com.br/judge/en/problems/view/1007" target="_blank">1007</a></center></td>
<td title="Salary"><center><a href="https://www.urionlinejudge.com.br/judge/en/problems/view/1008" target="_blank">1008</a></center></td>
<td title="Simple Calculate"><center><a href="https://www.urionlinejudge.com.br/judge/en/problems/view/1010" target="_blank">1010</a></center></td>
</table>


</center>
</font>
</font>
</div>
</td>
<td style="padding: 0px; vertical-align: top;">
<div id="rightAd">


</div>
</td>
</tr>
</table>
</center>
<!-- end page -->
<!-- start footer -->
<div id="footer">
<p id="legal">A2OJ &copy; Copyright 2010-2019 <b><a
	href="https://www.facebook.com/ahmed.aly.tc" target="_blank"
	style="text-decoration: none;">Ahmed Aly</a></b> All Rights Reserved. A2OJ uses <a href="http://sphere-engine.com" target="_blank" style="text-decoration: none;">Sphere Engine</a>&trade; &copy; by <a href="http://sphere-research.com" target="_blank" style="text-decoration: none;">Sphere Research Labs</a>.</p>
</div>
</td>


</tr>
</table>
</center>
<!-- end footer -->


</body>
</html>
